package days;

public enum DAYSOFWEEK {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Sunday,
    Saturday
}
