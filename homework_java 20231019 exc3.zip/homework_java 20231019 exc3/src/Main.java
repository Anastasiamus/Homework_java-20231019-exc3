import days.DAYSOFWEEK;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите сегодняшний день недели: ");
        Scanner scr = new Scanner(System.in);
        DAYSOFWEEK userchoice = DAYSOFWEEK.valueOf(scr.nextLine());
        for (DAYSOFWEEK d :DAYSOFWEEK.values()){
            System.out.println( d == userchoice ? "" : d );




        }
        

            
        }
        

                }
                //Используйте foreach.
//Дан Enum дней недели.
// Пользователь вводит имя текущего дня в консоль.
// Программа должна вывести все дни недели, кроме данного.